<html>
<head>
<title> FORMULARIO.PHP</title>
</head>
<body>
<form method = "POST" action="sumar.php">
	<p>valor 1: <input type = "text" name = "T1" size="20"></p>
	<p>valor 2: <input type = "text" name = "T2" size="20"></p>
	<p><input type = "submit" value = "Sumar" name="B1"></p>
	</form>
	</body>
	</html>
	